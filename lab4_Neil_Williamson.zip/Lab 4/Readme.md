Lab practicing a basic implementation of a queue data structure
